# Map-Reducer

Este programa ejecuta el algoritmo Map-Reducer sobre un conjunto de textos y devuelve como salida los resultados tras ejecutar el algoritmo MAP y los resultados tras ejecutar el algoritmo REDUCE con la salida del algoritmo MAP. Este programa sólo reconocerá las palabras _blanco_, _negro_ y _rojo_.

# Ejecución

Para usar el programa, se ha creado un fichero de texto que contiene una frase la cual contiene las palabras objetivo (_blanco_, _negro_ y _rojo_). Una vez hemos insertado el texto, bastaría con ejecutar el siguiente comando para ver los resultados.

> cat word_count.txt | python map_reducer.py